import 'package:flutter/material.dart';
import 'package:lung_cancer/Core/Utils/App%20Colors.dart';
import 'package:lung_cancer/Core/Utils/App%20Textstyle.dart';
import 'package:lung_cancer/Features/Reports/presentaion/widgets/report_duration_filter_button.dart';


enum ReportDuration { day, week, month }

class ReportSectionHeader extends StatelessWidget {
  final String title;
  final Function(ReportDuration reportDuration) onReportDurationChanged;

  final String? subtitle;

  const ReportSectionHeader({
    super.key,
    required this.title,
    required this.onReportDurationChanged,
    this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (subtitle != null) ...[
                Text(
                  title,
                  style: AppTextStyles.subTitle.copyWith(
                    fontSize: 16
                  ),),
                const SizedBox(height: 4),
              ],
              Text(
                subtitle ?? title,
                style: AppTextStyles.titleText3.copyWith(
                  fontSize: 22
                )
              ),
            ],
          ),
        ),
        const SizedBox(width: 16),
        ReportDurationFilterButton(
          label: 'D',
          active:true,
          onTap: () => onReportDurationChanged(ReportDuration.day),
        ),
        const SizedBox(width: 16),
        ReportDurationFilterButton(
          label: 'M',
          active: false,
          onTap: () => onReportDurationChanged(ReportDuration.week),
        ),
        const SizedBox(width: 16),
        ReportDurationFilterButton(
          label: 'Y',
          active:false,
          onTap: () => onReportDurationChanged(ReportDuration.month),
        ),
      ],
    );
  }
}
