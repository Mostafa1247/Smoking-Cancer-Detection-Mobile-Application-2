import 'package:flutter/material.dart';
import 'package:lung_cancer/Core/Utils/App%20Colors.dart';


import 'bar_chart_bar.dart';

class BarChartDay extends StatefulWidget {
  final String label;
  final double expensesPercentage;
  final double savingsPercentage;
  final int savingByDay;
  final int expensesByDay;
  final bool active;

  const BarChartDay({
    super.key,
    required this.savingByDay,
    required this.label,
    required this.expensesPercentage,
    required this.savingsPercentage,
    required this.active, required this.expensesByDay,
  });

  @override
  State<BarChartDay> createState() => _BarChartDayState();
}

class _BarChartDayState extends State<BarChartDay> {
    bool isBar = false;
    bool isBar2 = false;
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.bottomCenter,
      clipBehavior: Clip.none,
      children: [
        Container(
          height: 315,
          padding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 24,
          ),
          decoration: BoxDecoration(
            color: AppColors.grey,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            children: [
              Expanded(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    InkWell(
                      onTap :(){
                        setState(() {
                          isBar2 = !isBar2;
                        });
                      },
                      child: BarChartBar(
                        percentage: widget.expensesPercentage,
                        color: AppColors.red,
                      ),
                    ),
                    const SizedBox(width: 4),
                    InkWell(
                      onTap: (){
                        setState(() {
                          isBar = !isBar;
                        });
                      },
                      child: BarChartBar(
                        percentage: widget.savingsPercentage,
                        color:  const Color(0xff428DFC)
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Text(
                widget.label,
                style: const TextStyle(
                  color: AppColors.darkGrey,
                  fontSize: 10,
                ),
              ),
            ],
          ),
        ),
        isBar== true ? widget.savingByDay <= 0 ?Container() : Positioned(
          top: 5,
          child: Center(
            child: Container(
              width: 70,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                  color: const Color(0xff428DFC)
              ),
              child: Padding(
                padding: const EdgeInsets.all(5.0),
                child: Center(
                  child: Text(
                    "${widget.savingByDay} People",
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppColors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold
                    ),
                  ),
                ),
              ),
            ),
          ),
        ) : Container(),
        isBar2 == true ? widget.savingByDay <= 0 ?Container() : Positioned(
          top: 20,
          child: Center(
            child: Container(
              width: 70,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.red.shade200,
              ),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(3.0),
                  child: Text(
                    "${widget.expensesByDay} People",
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(
                        color: AppColors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold
                    ),
                  ),
                ),
              ),
            ),
          ),
        ) : Container(),
        if (widget.active)
          Positioned(
            bottom: -10,
            child: Container(
              width: 20,
              height: 20,
              decoration: const BoxDecoration(
                color: AppColors.black,
                shape: BoxShape.circle,
                border: Border.fromBorderSide(
                  BorderSide(
                    color: AppColors.white,
                    width: 4,
                  ),
                ),
              ),
            ),
          )
      ],
    );
  }
}
