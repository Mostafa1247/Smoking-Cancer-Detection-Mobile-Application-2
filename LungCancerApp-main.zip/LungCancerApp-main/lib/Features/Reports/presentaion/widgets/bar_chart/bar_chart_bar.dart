import 'package:flutter/material.dart';
import 'package:lung_cancer/Core/Utils/App%20Colors.dart';

class BarChartBar extends StatelessWidget {
  final double percentage;
  final Color color;

  const BarChartBar({
    super.key,
    required this.percentage,
    this.color = AppColors.blue,
  });

  @override
  Widget build(BuildContext context) {
    return FractionallySizedBox(
      heightFactor: percentage,
      child: Container(
        width: 18,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              color.withOpacity(0.90),
              color.withOpacity(0.50),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
          borderRadius: BorderRadius.circular(4),
        ),
      ),
    );
  }
}
