
import 'package:flutter/material.dart';
import 'package:lung_cancer/Core/Utils/App%20Colors.dart';

class ReportDurationFilterButton extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;

  const ReportDurationFilterButton({
    super.key,
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ClipOval(
      child: Material(
        color: active
            ? AppColors.blue
            : AppColors.mediumGrey.withOpacity(0.20),
        child: InkWell(
          onTap: onTap,
          child: SizedBox(
            width: 40,
            height: 40,
            child: Center(
              child: Text(
                label,
                style: TextStyle(
                  color:
                      active ? AppColors.white : AppColors.mediumGrey,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  height: 1,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
