import 'package:awesome_circular_chart/awesome_circular_chart.dart';
import 'package:flutter/material.dart';
import 'package:lung_cancer/Core/Utils/App%20Colors.dart';

class ExpensesChart extends StatefulWidget {
  final String totalValue;
  final double foodPercentage;
  final double drinksPercentage;

  const ExpensesChart({
  super.key,
  required this.totalValue,
  required this.foodPercentage,
  required this.drinksPercentage,
  });

  @override
  State<ExpensesChart> createState() => ExpensesChartState();
}

class ExpensesChartState extends State<ExpensesChart> {
  late final data = [
    CircularStackEntry(
      [
        CircularSegmentEntry(widget.foodPercentage,AppColors.primaryColor),
        CircularSegmentEntry(widget.drinksPercentage, AppColors.pink),
      ],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: 115,
      backgroundColor: AppColors.grey,
      child: AnimatedCircularChart(
        size: const Size.square(300),
        initialChartData: data,
        chartType: CircularChartType.Radial,
        edgeStyle: SegmentEdgeStyle.round,
        holeRadius: 40,
        holeLabel: widget.totalValue,
        labelStyle: const TextStyle(
          color: AppColors.black,
          fontSize: 20,
          fontWeight: FontWeight.w600,
          height: 1,
        ),
      ),
    );
  }
}
