import 'package:flutter/material.dart';
import 'package:lung_cancer/Core/Utils/App%20Colors.dart';


class ExpensesChartLegendItem extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const ExpensesChartLegendItem({
  super.key,
  required this.label,
  required this.value,
  this.color = AppColors.black,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Text(
            '$value',
            style: const TextStyle(
              color: AppColors.black,
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                radius: 8,
                backgroundColor: color,
              ),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: AppColors.darkGrey,
                  fontSize: 14,
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
