
import 'package:flutter/material.dart';

import '../../../../../../Core/Utils/App Colors.dart';
import 'expenses_chart_legend_item.dart';

class ExpensesChartLegend extends StatelessWidget {
  final String foodValue;
  final String drinksValue;
  final String orderValue;
  final num foodPercentage;
  final num otherPercentage;


  const ExpensesChartLegend({
    super.key,
    required this.foodValue,
    required this.drinksValue, required this.orderValue, required this.foodPercentage, required this.otherPercentage,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        IntrinsicHeight(
          child: Row(
            children: [
              Expanded(
                child: ExpensesChartLegendItem(
                  label: 'Women',
                  value: orderValue,
                  color: AppColors.pink,
                ),
              ),
              Container(
                width: 2,
                height: double.infinity,
                color: AppColors.mediumGrey.withOpacity(0.15),
              ),
              Expanded(
                child: ExpensesChartLegendItem(
                  label: 'Men',
                  value: drinksValue,
                  color: AppColors.primaryColor,

                ),
              ),
            ],
          ),
        ),
        Container(
          height: 2,
          width: double.infinity,
          color: AppColors.mediumGrey.withOpacity(0.15),
        ),
      ],
    );
  }
}
