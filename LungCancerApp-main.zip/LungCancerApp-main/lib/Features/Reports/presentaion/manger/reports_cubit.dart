import 'dart:ui';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lung_cancer/Core/Utils/App%20Colors.dart';
part 'reports_state.dart';

class ReportCubit extends Cubit<ReportsState> {
  ReportCubit() : super(ReportInitial());
  Map<String, Map<String, dynamic>> cancerData = {
    'Breast': {'New cases in 2020': 2261419, '% of all cancers': 12.5, 'Deaths in 2020': 685000},
    'Lung': {'New cases in 2020': 2206771, '% of all cancers': 12.2, 'Deaths in 2020': 1839364},
    'Colorectal': {'New cases in 2020': 1931590, '% of all cancers': 10.7, 'Deaths in 2020': 935371},
    'Prostate': {'New cases in 2020': 1414259, '% of all cancers': 7.8, 'Deaths in 2020': 379729},
    'Stomach': {'New cases in 2020': 1089103, '% of all cancers': 6.0, 'Deaths in 2020': 786733},
    'Liver': {'New cases in 2020': 905677, '% of all cancers': 5.0, 'Deaths in 2020': 831667},
    'Cervix uteri': {'New cases in 2020': 604127, '% of all cancers': 3.3, 'Deaths in 2020': 338969},
    'Oesophagus': {'New cases in 2020': 604100, '% of all cancers': 3.3, 'Deaths in 2020': 558526},
    'Thyroid': {'New cases in 2020': 586202, '% of all cancers': 3.2, 'Deaths in 2020': 8573},
    'Bladder': {'New cases in 2020': 573278, '% of all cancers': 3.2, 'Deaths in 2020': 206734},
    'Non-Hodgkin lymphoma': {'New cases in 2020': 544352, '% of all cancers': 3.0, 'Deaths in 2020': 190726},
    'Pancreas': {'New cases in 2020': 495773, '% of all cancers': 2.7, 'Deaths in 2020': 463335},
    'Leukaemia': {'New cases in 2020': 474519, '% of all cancers': 2.6, 'Deaths in 2020': 333477},
    'Kidney': {'New cases in 2020': 431288, '% of all cancers': 2.4, 'Deaths in 2020': 181054},
    'Corpus uteri': {'New cases in 2020': 417367, '% of all cancers': 2.3, 'Deaths in 2020': 85564},
    'Lip, oral cavity': {'New cases in 2020': 377713, '% of all cancers': 2.1, 'Deaths in 2020': 143825},
    'Melanoma of skin': {'New cases in 2020': 324635, '% of all cancers': 1.8, 'Deaths in 2020': 6850},
    'Ovary': {'New cases in 2020': 313959, '% of all cancers': 1.7, 'Deaths in 2020': 204463},
    'Brain, central nervous system': {'New cases in 2020': 308102, '% of all cancers': 1.7, 'Deaths in 2020': 203433},
    'Larynx': {'New cases in 2020': 184615, '% of all cancers': 1.0, 'Deaths in 2020': 125828},
    'Multiple myeloma': {'New cases in 2020': 176404, '% of all cancers': 1.0, 'Deaths in 2020': 113381},
    'Nasopharynx': {'New cases in 2020': 133354, '% of all cancers': 0.7, 'Deaths in 2020': 52451},
    'Gallbladder': {'New cases in 2020': 115949, '% of all cancers': 0.6, 'Deaths in 2020': 108199},
    'Oropharynx': {'New cases in 2020': 98412, '% of all cancers': 0.5, 'Deaths in 2020': 55363},
    'Hypopharynx': {'New cases in 2020': 84254, '% of all cancers': 0.5, 'Deaths in 2020': 52970},
    'Hodgkin lymphoma': {'New cases in 2020': 83087, '% of all cancers': 0.5, 'Deaths in 2020': 6025},
    'Testis': {'New cases in 2020': 74458, '% of all cancers': 0.4, 'Deaths in 2020': 627},
    'Salivary glands': {'New cases in 2020': 53583, '% of all cancers': 0.3, 'Deaths in 2020': 10483},
    'Vulva': {'New cases in 2020': 45240, '% of all cancers': 0.3, 'Deaths in 2020': 8969},
    'Penis': {'New cases in 2020': 36068, '% of all cancers': 0.2, 'Deaths in 2020': 3194},
    'Kaposi sarcoma': {'New cases in 2020': 34270, '% of all cancers': 0.2, 'Deaths in 2020': 14788},
    'Mesothelioma': {'New cases in 2020': 30870, '% of all cancers': 0.2, 'Deaths in 2020': 29426},
    'Vagina': {'New cases in 2020': 17908, '% of all cancers': 0.1, 'Deaths in 2020': 2250},
  };

  final List<SalesData> chartData = [
    SalesData(DateTime.now().year, 19.4 , AppColors.red),
    SalesData(DateTime.now().year -1,10.22 ,  AppColors.blue),
    SalesData(DateTime.now().year -2, 8.44 ,  AppColors.orange),
    SalesData(DateTime.now().year -3, 4.33 ,  AppColors.greenYellow),
    SalesData(DateTime.now().year - 5, 2.33 ,  AppColors.black)
  ];
}

class SalesData {
  SalesData(this.year, this.sales, this.color);
  final int year;
  final double sales;
  final Color color;
}