part of 'reports_cubit.dart';

sealed class ReportsState {}

final class ReportInitial extends ReportsState {}

final class MonthlyReportsLoading extends ReportsState {}

final class MonthlyReportsLoaded extends ReportsState {}

final class MonthlyReportsError extends ReportsState {
  final String message;

  MonthlyReportsError(this.message);
}

final class DayReportsLoading extends ReportsState {}

final class DayReportsLoaded extends ReportsState {}

final class DayReportsError extends ReportsState {
final String message;

DayReportsError(this.message);
}

final class WeeklyReportsLoading extends ReportsState {}

final class WeeklyReportsLoaded extends ReportsState {}

final class WeeklyReportsError extends ReportsState {
final String message;

WeeklyReportsError(this.message);
}

final class GetHomeDataLoading extends ReportsState {}

final class GetHomeDataLoaded extends ReportsState {}

final class GetHomeDataError extends ReportsState {
  final String message;

  GetHomeDataError(this.message);
}
