import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iconsax/iconsax.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../../../Core/Utils/App Colors.dart';
import '../../../../Core/Utils/App Textstyle.dart';
import '../../../../Core/Utils/Core Components.dart';
import '../../../../Core/Utils/message_widget.dart';
import '../manger/reports_cubit.dart';
import '../widgets/bar_chart/bar_chart_day.dart';
import '../widgets/expenses_chart/expenses_chart.dart';
import '../widgets/expenses_chart/expenses_chart_legend.dart';
import '../widgets/report_section_header.dart';

class ReportsTab extends StatefulWidget {
  const ReportsTab({super.key});

  @override
  State<ReportsTab> createState() => _ReportsTabState();
}

class _ReportsTabState extends State<ReportsTab> {
  @override
  void initState() {
    context.read<ReportCubit>().cancerData.forEach((cancerType, data) {
      double deathPercentage =
          (data['Deaths in 2020'] / data['New cases in 2020']) * 5;
      data['Death Percentage'] = deathPercentage;
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    const hasData = true;
    return BlocConsumer<ReportCubit, ReportsState>(
        listener: (context, state) async {},
        builder: (context, state) {
          var cubit = context.read<ReportCubit>();
          return state is WeeklyReportsLoading ||
                  state is MonthlyReportsLoading ||
                  state is DayReportsLoading ||
                  state is GetHomeDataLoading
              ? const Scaffold(
                  body: Center(
                    child: LoadingWidget(color: Colors.green),
                  ),
                )
              : state is GetHomeDataError
                  ? Padding(
                      padding: EdgeInsets.all(10),
                      child: Center(
                        child: MessageWidget(message: state.message),
                      ),
                    )
                  : state is WeeklyReportsError
                      ? Padding(
                          padding: EdgeInsets.all(10),
                          child: Center(
                            child: MessageWidget(message: state.message),
                          ),
                        )
                      : state is DayReportsError
                          ? Padding(
                              padding: const EdgeInsets.all(10),
                              child: Center(
                                child: MessageWidget(message: state.message),
                              ),
                            )
                          : state is MonthlyReportsError
                              ? Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Center(
                                    child:
                                        MessageWidget(message: state.message),
                                  ),
                                )
                              : Scaffold(
                                  appBar: AppBar(
                                    title: Text(
                                      ' Reports ',
                                      style: AppTextStyles.titleText.copyWith(
                                          fontSize: 22, color: AppColors.black),
                                    ),
                                    centerTitle: true,
                                  ),
                                  body: SingleChildScrollView(
                                    physics: const BouncingScrollPhysics(),
                                    child: Padding(
                                      padding: const EdgeInsets.all(15.0),
                                      child: Column(
                                        children: [
                                          ReportSectionHeader(
                                            title: 'All Cancers',
                                            subtitle: "19,394,716",
                                            onReportDurationChanged:
                                                (ReportDuration
                                                    reportDuration) {},
                                          ),
                                          const SizedBox(
                                            height: 20,
                                          ),
                                          SizedBox(
                                            height: 325,
                                            child: ListView.separated(
                                              physics:
                                                  const BouncingScrollPhysics(),
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 24),
                                              scrollDirection: Axis.horizontal,
                                              itemCount:
                                                  cubit.cancerData.length,
                                              separatorBuilder: (_, __) {
                                                return const SizedBox(
                                                    width: 16);
                                              },
                                              itemBuilder: (context, index) {
                                                return Align(
                                                  alignment:
                                                      Alignment.topCenter,
                                                  child: BarChartDay(
                                                    savingByDay: cubit
                                                                .cancerData[
                                                            cubit
                                                                .cancerData.keys
                                                                .toList()[index]
                                                                .toString()]![
                                                        "New cases in 2020"],
                                                    label: cubit.cancerData.keys
                                                        .toList()[index],
                                                    expensesByDay:
                                                        cubit.cancerData[cubit
                                                                .cancerData.keys
                                                                .toList()[index]
                                                                .toString()]![
                                                            "Deaths in 2020"],
                                                    expensesPercentage: cubit
                                                                    .cancerData[
                                                                cubit
                                                                    .cancerData.keys
                                                                    .toList()[index]
                                                                    .toString()]![
                                                            "Death Percentage"] /
                                                        100,
                                                    savingsPercentage: cubit
                                                                    .cancerData[
                                                                cubit
                                                                    .cancerData.keys
                                                                    .toList()[index]
                                                                    .toString()]![
                                                            "% of all cancers"] /
                                                        100,
                                                    active: index == 0,
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 20,
                                          ),
                                          ReportSectionHeader(
                                            title: 'All Cancers',
                                            subtitle: "19,394,716",
                                            onReportDurationChanged:
                                                (ReportDuration
                                                    reportDuration) {},
                                          ),
                                          const SizedBox(
                                            height: 20,
                                          ),
                                          const ExpensesChart(
                                            totalValue: "19.393 M",
                                            drinksPercentage: 550,
                                            foodPercentage: 460,
                                          ),
                                          const ExpensesChartLegend(
                                            foodValue: "19.3 Million",
                                            drinksValue: " 9.4 Million",
                                            orderValue: "9.9 Million",
                                            foodPercentage: 0.55,
                                            otherPercentage: 0.5,
                                          ),
                                          const SizedBox(
                                            height: 20,
                                          ),
                                          ReportSectionHeader(
                                            title: 'All Cancers',
                                            subtitle: "19,394,716",
                                            onReportDurationChanged:
                                                (ReportDuration
                                                    reportDuration) {},
                                          ),
                                          const SizedBox(
                                            height: 20,
                                          ),
                                          Center(
                                              child: SfCartesianChart(
                                                  tooltipBehavior:
                                                      TooltipBehavior(
                                                          enable: true),
                                                  series: <ChartSeries>[
                                                LineSeries<SalesData, int>(
                                                    dataSource: cubit.chartData,
                                                    pointColorMapper:
                                                        (SalesData data, _) =>
                                                            data.color,
                                                    width: 5,
                                                    enableTooltip: true,
                                                    xValueMapper:
                                                        (SalesData sales, _) =>
                                                            sales.year,
                                                    yValueMapper:
                                                        (SalesData sales, _) =>
                                                            sales.sales)
                                              ])),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
        });
  }
}
