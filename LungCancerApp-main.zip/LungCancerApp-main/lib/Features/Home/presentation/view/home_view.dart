

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lung_cancer/Core/Utils/App%20Colors.dart';
import 'package:lung_cancer/Core/Utils/App%20Textstyle.dart';
import 'package:lung_cancer/Core/Utils/Shared%20Methods.dart';
import '../../../Diagnosis/presenatation/view/add_picture_page.dart';
import '../manger/Medical_Bloc.dart';
import '../manger/Medical_States.dart';


class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context){
        return MedicalCubit();
      },
      child: BlocConsumer<MedicalCubit, MedicalStates>(
        listener: (context, state) {},
        builder: (context, state) {
          var cubit = MedicalCubit.get(context);
          return Scaffold(
            body: Padding(
              padding: const EdgeInsets.only(left: 10, right: 10, top: 5),
              child: Column(
                children: [
                  const SizedBox(
                    height: 22,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const SizedBox(
                        height: 50,
                         width: 180,
                        // child: Image.asset(
                        //   "Images/Cancerpy.jpg",
                        //   fit: BoxFit.fill,
                        // ),
                      ),
                      Container(
                          height: 42,
                          width: 48,
                          decoration: BoxDecoration(
                              color: const Color(0xff428DFC),
                              borderRadius: BorderRadius.circular(9)),
                          child: IconButton(
                              onPressed: () {},
                              icon: const Icon(
                                Icons.edit_road,
                                color: Colors.white,
                                size: 20,
                              )))
                    ],
                  ),

                  Row(
                    children: [
                      const SizedBox(
                        width: 4,
                      ),
                      SizedBox(
                        width: 280,
                        child: Text(
                          "Let's Diagnosis your Image",
                          style: AppTextStyles.titleText3.copyWith(
                            color: AppColors.black,
                            fontSize: 24
                          ),
                        ),
                      ),
                    ],
                  ),
                  Expanded(
                    child: GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 15.0,
                        childAspectRatio: 0.68
                      ),
                      itemCount: cubit.categories.length,
                      itemBuilder: (BuildContext ctx, index) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 20),
                          child: Container(
                            decoration: BoxDecoration(
                              color: const Color(0xff428DFC).withOpacity(0.3),
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white.withOpacity(0.5),
                                  spreadRadius: 2,
                                  blurRadius: 2,
                                  offset: const Offset(1, 1),
                                )
                              ],
                            ),
                            child: Column(
                              children: [
                                const SizedBox(height: 20),
                                Text(
                                  cubit.categories[index].text,
                                  style: AppTextStyles.titleText4.copyWith(
                                    fontSize: 18,
                                    color: Colors.black87,
                                  ),
                                  maxLines: 1,
                                ),
                                const SizedBox(height: 15),
                                Expanded(
                                  flex: 4,
                                  child: Container(
                                    decoration: const BoxDecoration(
                                      color: Colors.white,
                                      shape: BoxShape.circle,
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.all(20),
                                      child: SizedBox(
                                        height: 80,
                                        width: 80,
                                        child: Image.asset(
                                          cubit.categories[index].img,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const Spacer(),
                                Expanded(
                                      flex: 3,
                                    child: Column(
                                  children: [
                                    Expanded(
                                      flex:2,
                                      child: Text(
                                      'Model Confidence: ${cubit.categories[index].accuracy}%',
                                      style: AppTextStyles.titleText4.copyWith(
                                        fontSize: 12,
                                        color: const Color(0xff428DFC),
                                      ),
                                      maxLines: 1,
                                    ),),
                                    Expanded(
                                      flex: 4,
                                      child: Padding(
                                        padding: const EdgeInsets.fromLTRB(10, 3, 10, 2),
                                        child: InkWell(
                                          onTap: (){
                                           navigateTo(context,  AddPicturePage(
                                             url: cubit.categories[index].url,
                                           ));
                                          },
                                          child: Container(
                                            decoration: const BoxDecoration(
                                              color: Color(0xff428DFC),
                                              shape: BoxShape.rectangle,
                                              borderRadius: BorderRadius.all(Radius.circular(8)),
                                            ),
                                            width: MediaQuery.of(context).size.width * 0.7,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                                              children: [
                                                Text(
                                                  'Diagnose',
                                                  style: AppTextStyles.titleText4.copyWith(fontSize: 16),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                )),
                                const SizedBox(height: 15),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),

                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
