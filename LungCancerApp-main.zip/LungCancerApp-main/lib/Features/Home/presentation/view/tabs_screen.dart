import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_lazy_indexed_stack/flutter_lazy_indexed_stack.dart';
import 'package:iconsax/iconsax.dart';
import 'package:lung_cancer/Features/Exercise/presentation/manger/exercise_cubit.dart';
import 'package:lung_cancer/Features/Home/presentation/manger/tabs_cubit.dart';
import 'package:lung_cancer/Features/Nutrition/presentation/manger/nutrition_cubit.dart';
import '../../../../Core/Utils/Core Components.dart';
import '../../../Account_Settings/presentation/view/account_screen.dart';
import '../../../Exercise/presentation/view/exercise_view.dart';
import '../../../Medical_Records/presenatation/view/medical_records_tab.dart';
import '../../../Nutrition/presentation/view/nutrition_view.dart';
import '../../../Reports/presentaion/manger/reports_cubit.dart';
import '../../../Reports/presentaion/view/reports_tab.dart';
import 'home_view.dart';

class TabsScreen extends StatelessWidget {
  const TabsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => TabsCubit()),
        BlocProvider(create: (context) {
          return ReportCubit();
        }),
        BlocProvider(create: (context) {
          return ExerciseCubit();
        }),
        BlocProvider(create: (context) {
          return NutritionCubit();
        }),
      ],
      child: BlocBuilder<TabsCubit, TabsState>(
        builder: (context, state) {
          return Scaffold(
            body: LazyIndexedStack(
              index: state.index,
              children: const [
                HomeScreen(),
                ExerciseView(),
                NutritionView(),
                ReportsTab(),
                MedicalRecordsTab(),
                AccountScreen(),
              ],
            ),
            bottomNavigationBar: CustomBottomNavigationBar(
              selectedIndex: state.index,
              onTap: (index) {
                context.read<TabsCubit>().changeTab(index);
              },
              items: [
                CustomBottomNavigationBarItem(
                  selected: state.index == 0,
                  label: 'Home',
                  icon: Iconsax.home,
                  coloredIcon: Iconsax.home1,
                ),
                CustomBottomNavigationBarItem(
                  selected: state.index == 1,
                  label: 'Exercises',
                  icon:Icons.directions_run_outlined,
                  coloredIcon: Icons.directions_run_outlined,
                ),
                CustomBottomNavigationBarItem(
                  selected: state.index == 2,
                  label: 'Nutrition',
                  icon: Icons.food_bank_outlined,
                  coloredIcon: Icons.food_bank_outlined,
                ),
                CustomBottomNavigationBarItem(
                  selected: state.index == 3,
                  label: 'Reports',
                  icon: Iconsax.chart,
                  coloredIcon: Iconsax.graph5,
                ),
                CustomBottomNavigationBarItem(
                  selected: state.index == 4,
                  label: 'Medical Records',
                  icon: Iconsax.activity,
                  coloredIcon: Iconsax.activity5,
                ),
                CustomBottomNavigationBarItem(
                  selected: state.index == 5,
                  label: 'Settings',
                  icon: Iconsax.setting,
                  coloredIcon: Iconsax.setting5,
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
