import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';

import '../view/exercise_view.dart';

part 'exercise_state.dart';

class ExerciseCubit extends Cubit<ExerciseState> {
  ExerciseCubit() : super(ExerciseInitial());

  final List<Activity> activities = [
    Activity(title: 'Run', icon: Icons.directions_run),
    Activity(title: 'Cycle', icon: Icons.directions_bike),
    Activity(title: 'Swim', icon: Icons.pool),
    Activity(title: 'Yoga', icon: Icons.self_improvement),
    Activity(title: 'Stair', icon: Icons.accessibility),
  ];
  changeActiveActivity(int index) {
    if (activities[index].isActive == true) {
      activities[index].isActive = !activities[index].isActive;
      activities[index].isClose = !activities[index].isClose;
      print(activities[index].isClose);
      lockAllExcept(index, false);
    } else {
      activities[index].isActive = !activities[index].isActive;
      lockAllExcept(index, true);
    }
    emit(ChangeExerciseState());
  }

  void lockAllExcept(int selectedIndex, bool isLock) {
    for (int i = 0; i < activities.length; i++) {
      if (i != selectedIndex) {
        activities[i].isLock = isLock;
      }
    }
    emit(ChangeIsLockState());
  }
}
