part of 'exercise_cubit.dart';

@immutable
abstract class ExerciseState {}

class ExerciseInitial extends ExerciseState {}
class ChangeExerciseState extends ExerciseState {}

class ChangeIsLockState extends ExerciseState {}
