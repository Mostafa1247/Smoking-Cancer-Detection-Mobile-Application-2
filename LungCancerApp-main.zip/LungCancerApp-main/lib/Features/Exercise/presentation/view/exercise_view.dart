import 'dart:async';
import 'dart:ui';

import 'package:lung_cancer/Core/Utils/App%20Colors.dart';
import 'package:lung_cancer/Core/Utils/App%20Textstyle.dart';
import 'package:lung_cancer/Core/Utils/top_snackbars.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../manger/exercise_cubit.dart';

class ExerciseView extends StatefulWidget {
  const ExerciseView({super.key});

  @override
  State<ExerciseView> createState() => _ExerciseViewState();
}

class _ExerciseViewState extends State<ExerciseView> {
  int secondsElapsed = 0;
  Timer? timer;
  DateTime? dateTime;

  void startTimer() {
    dateTime = DateTime.now();
    timer = Timer.periodic(const Duration(seconds: 1), (Timer t) {
      setState(() {
        secondsElapsed++;
      });
    });
  }

  Duration? elapsedTime;
  Future<void> stopTimer() async {
    elapsedTime = Duration(seconds: secondsElapsed);
    timer?.cancel();
    setState(() {
      secondsElapsed = 0;
    });
    print('Elapsed Time: ${formatDateTime(elapsedTime!)}');
  }

  String formatDateTime(Duration duration) {
    int totalMinutes = duration.inMinutes;
    int minutes = totalMinutes % 60;
    int hours = duration.inHours;

    String twoDigits(int n) {
      if (n >= 10) {
        return "$n";
      } else {
        return "0$n";
      }
    }

    if (hours > 0) {
      return '${twoDigits(hours)}:${twoDigits(minutes)} Hour';
    } else {
      return '${twoDigits(minutes)}:${twoDigits(duration.inSeconds % 60)} Min';
    }
  }

  String twoDigits(int n) {
    if (n >= 10) return "$n";
    return "0$n";
  }

  List<Exercise> exercises = [];

  String formatTime(int timeInSeconds) {
    int minutes = (timeInSeconds ~/ 60);
    int seconds = timeInSeconds % 60;
    return '${twoDigits(minutes)}:${twoDigits(seconds)}';
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ExerciseCubit(),
      child: BlocConsumer<ExerciseCubit, ExerciseState>(
        listener: (context, state) {},
        builder: (context, state) {
          var cubit = context.read<ExerciseCubit>();
          return Scaffold(
            appBar: AppBar(
              title: Text(
                "Exercises",
                style: AppTextStyles.titleText.copyWith(fontSize: 26 , color: AppColors.black),
              ),
              centerTitle: true,
            ),
              body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: AppColors.blue),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Flexible(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const CircleAvatar(
                                  radius: 26,
                                  backgroundColor: AppColors.white,
                                  child: Icon(
                                    Icons.timer_outlined,
                                    size: 33,
                                    color: AppColors.black,
                                  ),
                                ),
                                const SizedBox(
                                  height: 1,
                                ),
                                Text(
                                  "Time",
                                  style:
                                      AppTextStyles.titleText.copyWith(fontSize: 22 , color: AppColors.white),
                                )
                              ],
                            ),
                          ),
                          Row(
                            children: [
                              Text(
                                formatTime(secondsElapsed),
                                style:
                                    AppTextStyles.titleText.copyWith(fontSize: 50 , color: AppColors.white),
                              ),
                              Transform.translate(
                                offset: const Offset(0.0, 20.0),
                                child: Text(
                                  " Min ",
                                  style: AppTextStyles.titleText.copyWith(
                                    fontSize: 22,
                                      color: AppColors.white
                                  ),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: AppColors.white),
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(children: [
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Text(
                            "Start new activity",
                            style: AppTextStyles.titleText.copyWith(fontSize: 20),
                          ),
                        ),
                        const SizedBox(
                          height: 3,
                        ),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Text(
                            "Set goal and track",
                            style: AppTextStyles.subTitle.copyWith(
                                fontSize: 14, color: AppColors.darkGrey),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Container(
                          width: double.infinity,
                          height: 100,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: cubit.activities.length,
                            shrinkWrap: true,
                            itemBuilder: (BuildContext context, int index) {
                              return Padding(
                                padding:
                                    const EdgeInsets.fromLTRB(7, 10, 20, 5),
                                child: InkWell(
                                  onTap: () {
                                    if (cubit.activities[index].isLock ==
                                        true) {
                                      TopSnackbars().error(
                                          context: context,
                                          message:
                                              "He prefers completing the initial set of exercises before commencing a new set");
                                    } else {
                                      if (cubit.activities[index].isActive ==
                                          false) {
                                        startTimer();
                                        cubit.changeActiveActivity(index);
                                      } else {
                                        stopTimer();
                                        exercises.add(Exercise(
                                            name: cubit.activities[index].title,
                                            dateTime:" 2/1/2024 4:00 AM",
                                            duration:
                                                formatDateTime(elapsedTime!)));
                                        cubit.changeActiveActivity(index);
                                      }
                                    }
                                  },
                                  child: Column(
                                    children: [
                                      CircleAvatar(
                                        backgroundColor: cubit.activities[index]
                                                    .isActive ==
                                                true
                                            ? AppColors.green
                                            : cubit.activities[index].isClose ==
                                                    true
                                                ? AppColors.red
                                                : AppColors.grey,
                                        radius: 24,
                                        child: Icon(
                                            cubit.activities[index].icon,
                                            color: cubit.activities[index]
                                                        .isActive ==
                                                    true
                                                ? AppColors.white
                                                : AppColors.black),
                                      ),
                                      const SizedBox(height: 5),
                                      Text(
                                        cubit.activities[index].title,
                                        style: AppTextStyles.subTitle.copyWith(
                                          fontSize: 14,
                                          color: AppColors.black,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        )
                      ]),
                    ),
                  ),
                  ListView.builder(
                      shrinkWrap: true,
                      itemCount: exercises.length,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: AppColors.grey),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 15, vertical: 10),
                              child: Column(children: [
                                Align(
                                  alignment: Alignment.bottomLeft,
                                  child: Text(
                                    "Exercise  ${exercises[index].name}",
                                    style: AppTextStyles.titleText
                                        .copyWith(fontSize: 20),
                                  ),
                                ),
                                const SizedBox(
                                  height: 3,
                                ),
                                Align(
                                  alignment: Alignment.bottomLeft,
                                  child: Text(
                                    "${exercises[index].dateTime  } ${exercises[index].duration}",
                                    style: AppTextStyles.subTitle.copyWith(
                                        fontSize: 14,
                                        color: AppColors.darkGrey),
                                  ),
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                              ]),
                            ),
                          ),
                        );
                      })
                ],
              ),
            ),
          ));
        },
      ),
    );
  }
}

class Activity {
  final String title;
  final IconData icon;
  bool isActive;
  bool isClose;
  bool isLock;

  Activity(
      {required this.title,
      required this.icon,
      this.isActive = false,
      this.isClose = false,
      this.isLock = false});
}

class Exercise {
  String name;
  String dateTime;
  String duration;

  Exercise({
    required this.name,
    required this.dateTime,
    required this.duration,
  });
}
