import 'package:flutter_bloc/flutter_bloc.dart';

part 'medical_records_state.dart';

class MedicalRecordsCubit extends Cubit<MedicalRecordsState> {
  MedicalRecordsCubit() : super(TabsInitial());

}
