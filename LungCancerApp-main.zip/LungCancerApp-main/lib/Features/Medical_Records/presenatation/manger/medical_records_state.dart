part of 'medical_records_cubit.dart';

abstract class MedicalRecordsState {
  final int index;

  const MedicalRecordsState({required this.index});
}

class TabsInitial extends MedicalRecordsState {
  TabsInitial() : super(index: 0);
}

class TabChanged extends MedicalRecordsState {
  const TabChanged(int index) : super(index: index);
}
