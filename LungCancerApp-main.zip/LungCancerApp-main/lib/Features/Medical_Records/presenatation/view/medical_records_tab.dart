import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lung_cancer/Core/Utils/App%20Textstyle.dart';

import '../../../../Core/Utils/App Colors.dart';
import '../../../../Core/Utils/Core Components.dart';
import '../manger/medical_records_cubit.dart';

class MedicalRecordsTab extends StatefulWidget {
  const MedicalRecordsTab({super.key});

  @override
  State<MedicalRecordsTab> createState() => _MedicalRecordsTabState();
}

class _MedicalRecordsTabState extends State<MedicalRecordsTab> {
  int _currentTabIdx = 0;

  void _onTabChanged(int index) {
    if (index == _currentTabIdx) return;
    setState(() => _currentTabIdx = index);
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => MedicalRecordsCubit(),
      child: BlocConsumer<MedicalRecordsCubit, MedicalRecordsState>(
        listener: (context, state) {},
        builder: (context, state) {
          return Scaffold(
            appBar: AppBar(
              title:  Text('Medical Reports' , style: AppTextStyles.titleText.copyWith(
                fontSize: 22,
                color: AppColors.black
              ),),
              centerTitle: true,
            ),
            body: Builder(builder: (context) {
              return Column(
                children: [
                  const SizedBox(height: 10,),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.91,
                    child: CustomTabBar(
                      itemPadding: const EdgeInsets.all(12),
                      backgroundColor: AppColors.grey,
                      disableShadow: true,
                      tabs: const [
                        'Positive Cases',
                        'Negative Cases',
                      ],
                      selectedIndex: _currentTabIdx,
                      onTabChanged: _onTabChanged,
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.all(24),
                    child: MessageCard(
                      title: 'Medical Cases Status',
                      body: 'No new medical cases found. You will be notified when there are updates.',
                      svgAsset: "",
                    ),
                  ),
                ],
              );
            }),
          );
        },
      ),
    );
  }
}
