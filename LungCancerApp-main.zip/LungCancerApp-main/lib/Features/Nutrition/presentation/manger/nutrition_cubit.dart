import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';

import '../../../../../Core/Utils/Assets Manager.dart';
import '../view/nutrition_view.dart';

part 'nutrition_state.dart';

class NutritionCubit extends Cubit<NutritionState> {
  NutritionCubit() : super(NutritionInitial());

  int currentIndex = 0;

  final List<Map<String, dynamic>> items = [
    {"index": 0, "iconData": Icons.home, "isSelected": false},
    {"index": 1, "iconData": Icons.favorite, "isSelected": false},
    {"index": 2, "iconData": Icons.filter_list, "isSelected": false},
  ];

  changeCurrentIndex(int index) {
    currentIndex = index;
    emit(ChangeCurrentIndex());
  }

  changeFav(index) {
    foodItems[index].isFav = !foodItems[index].isFav;
    emit(ChangeFavItem());
  }

  changeFavItems(foodItems, index) {
    foodItems[index].isFav = !foodItems[index].isFav;
    emit(ChangeFavItem());
  }

  changeFilterFood(foodItems, index) {
    foodItems[index].isFav = !foodItems[index].isFav;
    emit(ChangeFavFilterFood());
  }
  List<FoodItem> foodItems = [
    FoodItem(title: "Pizza", foodImage: AssetsManager.foodIMG, allergies: {
      'Dairy': true,
      'Gluten': false,
      'Egg': false,
      'Peanuts': false,
      'Tree Nuts': false,
    }),
    FoodItem(title: "Burger", foodImage: AssetsManager.foodIMG, allergies: {
      'Egg': true,
      'Dairy': false,
      'Gluten': false,
      'Peanuts': false,
      'Tree Nuts': false,
    }),
    FoodItem(title: "Pasta", foodImage: AssetsManager.foodIMG, allergies: {
      'Gluten': true,
      'Dairy': false,
      'Egg': false,
      'Peanuts': false,
      'Tree Nuts': false,
    }),
    FoodItem(title: "Salad", foodImage: AssetsManager.foodIMG, allergies: {
      'Dairy': false,
      'Gluten': false,
      'Egg': false,
      'Peanuts': false,
      'Tree Nuts': false,
    }),
  ];
}
