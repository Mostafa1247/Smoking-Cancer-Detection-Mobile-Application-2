part of 'nutrition_cubit.dart';

@immutable
abstract class NutritionState {}

class NutritionInitial extends NutritionState {}
class ChangeCurrentIndex extends NutritionState {}
class ChangeFavItem extends NutritionState {}
class ChangeSelectedItem extends NutritionState {}

class ChangeFavFilterFood extends NutritionState {}
