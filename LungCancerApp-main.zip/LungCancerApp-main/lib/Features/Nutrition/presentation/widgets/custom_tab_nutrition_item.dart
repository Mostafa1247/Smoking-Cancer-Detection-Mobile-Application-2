import 'package:flutter/material.dart';

import '../../../../../Core/Utils/App Colors.dart';

class CustomTabNutritionItem extends StatelessWidget {
  final Color borderColor;
  final double borderWidth;
  final double borderRadius;
  final IconData icon;
  final double iconSize;
  final Color iconColor;

  const CustomTabNutritionItem({
    Key? key,
    this.borderColor = AppColors.primaryColor,
    this.borderWidth = 3.0,
    this.borderRadius = 14,
    this.icon = Icons.home_filled,
    this.iconSize = 35,
    this.iconColor = AppColors.primaryColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15.0),
      decoration: BoxDecoration(
        border: Border.all(
          color: borderColor,
          width: borderWidth,
        ),
        borderRadius: BorderRadius.circular(borderRadius),
      ),
      child: Icon(
        icon,
        size: iconSize,
        color: iconColor,
      ),
    );
  }
}