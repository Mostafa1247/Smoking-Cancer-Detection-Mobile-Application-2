import 'package:lung_cancer/Core/Utils/App%20Textstyle.dart';
import 'package:lung_cancer/Core/Utils/Assets%20Manager.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multi_selection_filter/multi_selection_filter.dart';
import '../../../../../Core/Utils/App Colors.dart';
import '../manger/nutrition_cubit.dart';
import '../widgets/custom_tab_nutrition_item.dart';

class NutritionView extends StatefulWidget {
  const NutritionView({super.key});

  @override
  State<NutritionView> createState() => _NutritionViewState();
}

class _NutritionViewState extends State<NutritionView> {
  final allergens = {
    'Dairy': false,
    'Gluten': false,
    'Egg': false,
    'Peanuts': false,
    'Tree Nuts': false,
  };

  Widget _buildFilterWidget(itemIndex, currentIndex) {
    return BlocConsumer<NutritionCubit, NutritionState>(
      listener: (context, state) {},
      builder: (context, state) {
        var cubit = context.read<NutritionCubit>();
        return Align(
          alignment: Alignment.topCenter,
          child: MultiSelectionFilter(
              title: "Allergy Filters \nDietary Restrictions",
              textListToShow: allergens.keys.toList(),
              doneButtonText: "                Save                ",
              selectedList: allergens.values.toList(),
              accentColor: AppColors.white,
              checkboxTitleBG: AppColors.white,
              checkboxCheckColor: Colors.black,
              checkboxTitleTextColor: Colors.black,
              doneButtonBG: AppColors.blue,
              doneButtonTextColor: Colors.white,
              onCheckboxTap: (key, index, isChecked) {
                setState(() {
                  allergens[key] = isChecked;
                });
              },
              onDoneButtonPressed: (){
                cubit.changeCurrentIndex(itemIndex);
                Navigator.pop(context);
              },
              child: CustomTabNutritionItem(
                borderColor: itemIndex == currentIndex
                    ? AppColors.blue
                    : AppColors.mediumGrey.withOpacity(0.4),
                borderWidth: 3.0,
                borderRadius: 14,
                icon: Icons.filter_alt,
                iconSize: 35,
                iconColor: itemIndex == currentIndex
                    ? AppColors.blue
                    : AppColors.mediumGrey.withOpacity(0.4),
              )),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => NutritionCubit(),
      child: BlocConsumer<NutritionCubit, NutritionState>(
        listener: (context, state) {},
        builder: (context, state) {
          NutritionCubit cubit = context.read<NutritionCubit>();
          List<FoodItem> favoriteFoodItems = cubit.foodItems
              .where((foodItem) => foodItem.isFav == true)
              .toList();

          List<FoodItem> filteredFoodItems = cubit.foodItems.where((foodItem) {
            return allergens.entries.every((entry) {
              String allergen = entry.key;
              bool hasAllergy = entry.value;
              return foodItem.allergies[allergen] == hasAllergy;
            });
          }).toList();

          print(allergens);
          print(filteredFoodItems);
          return Scaffold(
            appBar: AppBar(),
            body: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 17 ,),
                child: Column(
                  children: [
                    Align(
                      alignment: Alignment.bottomLeft,
                      child: Text(
                        "Nutrition",
                        style: AppTextStyles.titleText.copyWith(fontSize: 26),
                      ),
                    ),
                    const SizedBox(
                      height: 3,
                    ),
                    Align(
                      alignment: Alignment.bottomLeft,
                      child: Text(
                        "Choose delicious foods",
                        style: AppTextStyles.subTitle.copyWith(
                            fontSize: 16, color: AppColors.mediumGrey),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: cubit.items.map((e) {
                          return InkWell(
                            onTap: () {
                              cubit.changeCurrentIndex(e["index"]);
                              print("ff");
                            },
                            child: e["index"] == 2
                                ? _buildFilterWidget(
                                e["index"], cubit.currentIndex)
                                : CustomTabNutritionItem(
                              borderColor: cubit.currentIndex ==
                                  e["index"]
                                  ? AppColors.blue
                                  : AppColors.mediumGrey.withOpacity(0.2),
                              icon: e["iconData"],
                              iconColor: cubit.currentIndex == e["index"]
                                  ? AppColors.blue
                                  : AppColors.mediumGrey.withOpacity(0.4),
                            ),
                          );
                        }).toList()),
                    const SizedBox(
                      height: 30,
                    ),
                    GridView.builder(
                      gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 0.75,
                        mainAxisSpacing: 15,
                        crossAxisSpacing: 20,
                      ),
                      shrinkWrap: true,
                      itemCount: cubit.currentIndex == 1
                          ? favoriteFoodItems.length
                          : cubit.currentIndex == 2
                          ? filteredFoodItems.length
                          : cubit.foodItems.length,
                      itemBuilder: (BuildContext context, int index) {
                        List<FoodItem> foodItemsData = cubit.currentIndex == 1
                            ? favoriteFoodItems
                            : cubit.currentIndex == 2
                            ? filteredFoodItems
                            : cubit.foodItems;
                        return Container(
                          decoration: BoxDecoration(
                              color: AppColors.grey,
                              borderRadius: BorderRadius.circular(15)),
                          child: Padding(
                            padding: const EdgeInsets.all(6.0),
                            child: Column(
                              children: [
                                const SizedBox(
                                  height: 5,
                                ),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                                  children: [
                                    IconButton(
                                        onPressed: () {},
                                        icon: const Icon(
                                          Icons.control_point,
                                          size: 28,
                                          color: AppColors.blue,
                                        )),
                                    IconButton(
                                        onPressed: () {
                                          cubit.currentIndex == 1
                                              ? cubit.changeFavItems(
                                              favoriteFoodItems, index):
                                          cubit.currentIndex == 2
                                              ? cubit.changeFilterFood(filteredFoodItems ,index)
                                              : cubit.changeFav(index);
                                        },
                                        icon: Icon(
                                          foodItemsData[index].isFav == true
                                              ? Icons.favorite
                                              : Icons.favorite_border,
                                          size: 28,
                                          color: foodItemsData[index].isFav == true
                                              ? AppColors.red
                                              : AppColors.mediumGrey
                                              .withOpacity(0.4),
                                        ))
                                  ],
                                ),
                                Expanded(
                                    child: Center(
                                      child: Image.asset(
                                        AssetsManager.foodIMG,
                                        fit: BoxFit.fill,
                                      ),
                                    )),
                                const SizedBox(
                                  height: 5,
                                ),
                                Align(
                                  alignment: Alignment.bottomLeft,
                                  child: Padding(
                                    padding: const EdgeInsets.all(14.0),
                                    child: Text(
                                      foodItemsData[index].title,
                                      overflow: TextOverflow.ellipsis,
                                      style: AppTextStyles.titleText.copyWith(
                                          fontSize: 16,
                                          color:
                                          AppColors.black.withOpacity(0.9)),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class FoodItem {
  String title;
  String foodImage;
  bool isFav;
  Map<String, bool> allergies;

  FoodItem({
    required this.title,
    required this.foodImage,
    this.isFav = false,
    Map<String, bool>? allergies,
  }) : allergies = allergies ??
      {
        'Dairy': false,
        'Gluten': false,
        'Egg': false,
        'Peanuts': false,
        'Tree Nuts': false,
      };
}
