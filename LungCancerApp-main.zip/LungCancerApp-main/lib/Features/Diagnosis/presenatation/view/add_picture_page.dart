import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iconsax/iconsax.dart';
import 'package:lung_cancer/Features/Diagnosis/presenatation/manger/patient_diagnosis_cubit.dart';
import '../../../../../../../Core/Ui/primary_button.dart';
import '../../../../../../../Core/Utils/App Textstyle.dart';
import '../../../../Core/Utils/App Colors.dart';
import '../widgets/choose_image_bottom_sheet.dart';
import '../widgets/picture_source_button.dart';

class AddPicturePage extends StatefulWidget {
  final String url;
  const AddPicturePage({
    super.key,
    required this.url,
  });

  @override
  State<AddPicturePage> createState() => _AddPicturePageState();
}

class _AddPicturePageState extends State<AddPicturePage> {
  void _pickImage() async {
    final pickedImagePath = await const ChooseImageBottomSheet().show(context);
    print(pickedImagePath);
    if (pickedImagePath == null) return;
    setState(() => _pickedImagePath = pickedImagePath);
  }

  String? _pickedImagePath;
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) {
        return PatientDiagnosisCubit();
      },
      child: BlocConsumer<PatientDiagnosisCubit, PatientDiagnosisState>(
          listener: (context, state) {
        // if (state is SetGoalLoaded) {
        //   ServiceLocator.instance<Snackbars>().success(
        //     context: context,
        //     message: state.message,
        //   );
        //   Navigator.of(context).pushReplacement(
        //     MaterialPageRoute(
        //       builder: (context) =>
        //           const TabsScreen(), ),
        //   );
        // }
        // if (state is SetGoalErrorState) {
        //   ServiceLocator.instance<Snackbars>().error(
        //     context: context,
        //     message: state.message,
        //   );
        //   Navigator.of(context).pushReplacement(
        //     MaterialPageRoute(
        //       builder: (context) =>
        //           const TabsScreen(),
        //     ),
        //   );
        // }
      }, builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            shadowColor: Colors.grey.shade100,
            title: Text(
              "Uploading an Image",
              style: AppTextStyles.titleText3.copyWith(fontSize: 18 ,
                  color: Colors.black
              ),
            ),
            elevation: 1,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_rounded,
                  size: 20, color: Colors.black),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      children: [
                        const SizedBox(height: 30),
                         Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: Text(
                            'Would you like to place a radiographic image ?',
                            textAlign: TextAlign.center,
                            style: AppTextStyles.titleText3.copyWith(
                              fontSize: 16,
                              color: Colors.black
                            ))
                        ),
                        const SizedBox(height: 40),
                        PictureSourceButton(
                          icon: Iconsax.camera,
                          label: 'upload / take picture ',
                          onTap: _pickImage,
                        ),
                        const SizedBox(height: 30),
                        if (_pickedImagePath != null)
                          AspectRatio(
                            aspectRatio: 1.1,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: Image.file(
                                File(_pickedImagePath!),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                PrimaryButton(
                  backgroundColor: AppColors.blue,
                  foregroundColor: AppColors.white,
                  // isLoading: state is SetGoalLoading ,
                  label: 'Upload Image',
                  onPressed: () {
                    print(widget.url);
                    // context.read<ChildProfileCubit>().setGoal(
                    //     childId: widget.childId!,
                    //     amount: widget.totalPrice,
                    //     image:_pickedImagePath ?? "",
                    //     name: widget.goalName);
                  },
                ),
              ],
            ),
          ),
        );
      }),
    );
  }
}
