import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import '../../data/models/SocialUserModel.dart';
import 'Login_States.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class LoginCubit extends Cubit<LoginStates> {
  LoginCubit() : super(LoginInitialState());

  static LoginCubit get(context) {
    return BlocProvider.of(context);
  }

  void loginUser(String email, String password) {
    emit(LoginLoadingState());
    FirebaseAuth.instance
        .signInWithEmailAndPassword(email: email, password: password)
        .then((value) {
      emit(LoginSuccessState(value.user!.uid));
      print(value.user!.uid);
    }).catchError((onError) {
      emit(LoginErrorState(onError.message.toString()));
    });
  }

  bool obscureText = false;
  void showPassword() {
    obscureText = (!obscureText);
    if (kDebugMode) {
      print(obscureText);
    }
    emit(ChangeShowPasswordState());
  }
  final formKey = GlobalKey<FormBuilderState>();

  final formKey2 = GlobalKey<FormBuilderState>();

  Map<String, dynamic>? getFormData() {
    final formState = formKey.currentState;

    if (formState == null) return null;
    if (formState.saveAndValidate() == false) return null;

    return formState.value;
  }

  Map<String, dynamic>? getFormData2() {
    final formState = formKey2.currentState;

    if (formState == null) return null;
    if (formState.saveAndValidate() == false) return null;

    return formState.value;
  }

  void createUser(
      {required String email,
        required String password,
        required String name,
        required String uid}) {
    SocialUserModel model = SocialUserModel(
        email: email,
        name: name,
        uId: uid,
        isEmailVerified: false,
        image: "https://i.ibb.co/ky10h4d/undraw-profile-pic-ic5t.png",
        bio: "Dear diet, things just aren’t looking good for the both of us. It’s not me, it’s you. You’re too much work",
        cover:
        "https://images.pexels.com/photos/358382/pexels-photo-358382.jpeg?cs=srgb&dl=pexels-pixabay-358382.jpg&fm=jpg");
    FirebaseFirestore.instance
        .collection("Users")
        .doc(uid)
        .set(model.toMap())
        .then((value) {
      emit(CreateUserSuccessState(model));
    }).catchError((onError) {
      emit(CreateUserErrorState(onError.message.toString()));
    });
  }

  void registrationUser(
      {required String email, required String password, required String name}) {
    emit(RegistrationLoadingState());
    FirebaseAuth.instance
        .createUserWithEmailAndPassword(email: email, password: password)
        .then((value) {
      createUser(
          email: email,
          password: password,
          name: name,
          uid: value.user!.uid);
      emit(RegistrationSuccessState(value.user!.uid));
    }).catchError((onError) {
      emit(RegistrationErrorState(onError.message.toString()));
    });
  }
}
