import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:lung_cancer/Core/Utils/App%20Textstyle.dart';
import 'package:lung_cancer/Core/Utils/Assets%20Manager.dart';
import 'package:lung_cancer/Core/Utils/Shared%20Methods.dart';

import '../../../../Core/UI/primary_button.dart';
import '../../../../Core/Utils/App Colors.dart';
import '../../../../Core/Utils/Core Components.dart';
import '../../../../Core/Utils/Shared_preferences.dart';
import '../../../../Core/Utils/top_snackbars.dart';
import '../../../Medical_Examination/presentation/view/medical_examination_view.dart';
import '../manger/Login_Bloc.dart';
import '../manger/Login_States.dart';
import 'Signup_Screen.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    AppBar appBar = AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      leading: Container(),
    );
    final mediaQueryHeight = MediaQuery.of(context).size.height;
    final mediaQueryWidth = MediaQuery.of(context).size.width;
    final mediaQueryTop = MediaQuery.of(context).padding.top;
    final mediaQuery =
        (mediaQueryHeight - appBar.preferredSize.height - mediaQueryTop);
    return BlocProvider(
      create: (context) {
        return LoginCubit();
      },
      child: BlocConsumer<LoginCubit, LoginStates>(
        listener: (BuildContext context, state) {
          if (state is LoginSuccessState) {
            TopSnackbars().success(context: context, message:  "Login successful! Welcome!");
            CacheHelper.saveData("token", state.uId)?.then((value){
              print(state.uId);
              navigateAndFinished(context, const MedicalExaminationView());
            }).catchError((onError){

            });

          }
          if (state is LoginErrorState) {
            TopSnackbars()
                .error(context: context, message: state.error.toString());
          }
        },
        builder: (BuildContext context, Object? state) {
          var cubit = LoginCubit.get(context);
          Map<String, dynamic>? getFormData() {
            final formState = cubit.formKey.currentState;

            if (formState == null) return null;
            if (formState.saveAndValidate() == false) return null;

            return formState.value;
          }
          return Scaffold(
            backgroundColor: Colors.white,
            appBar: appBar,
            body: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 13),
              child: CustomScrollView(
                physics: const ScrollPhysics(),
                keyboardDismissBehavior:
                    ScrollViewKeyboardDismissBehavior.onDrag,
                shrinkWrap: true,
                slivers: [
                  SliverFillRemaining(
                    hasScrollBody: false,
                    child: FormBuilder(
                      key: cubit.formKey,
                      child: SizedBox(
                        height: mediaQuery,
                        child: Column(
                          children: [
                            Expanded(
                              flex: 3,
                              child:  Hero(
                                tag: "sign",
                                child: Image.asset(
                                  AssetsManager.onBoarding1,
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                            SizedBox(height: mediaQuery * 0.01),
                            Padding(
                              padding: EdgeInsets.all(mediaQuery * 0.014),
                              child: Container(
                                alignment: Alignment.topLeft,
                                height: mediaQuery * 0.060,
                                child: FittedBox(
                                  child: Hero(
                                    tag: "login",
                                    child: Text(
                                      "Login",
                                      style: AppTextStyles.titleText,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                                flex: 5,
                                child: LayoutBuilder(
                                  builder: (BuildContext context,
                                      BoxConstraints constraints) {
                                    return Column(children: [
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: TextFieldTemplate(
                                          name: 'username',
                                          label: 'Enter The Email',
                                          leadingIcon: Icons.mail_outline,
                                          boolleadingIcon: true,
                                          leadingIconColor:
                                              AppColors.greenYellow,
                                          enableFocusBorder: false,
                                          titel: "Email",
                                          validator:
                                              FormBuilderValidators.compose([
                                            FormBuilderValidators.required(),
                                          ]),
                                        ),
                                      ),
                                      SizedBox(
                                        height: constraints.maxHeight * 0.02,
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: TextFieldTemplate(
                                          titel: "Password",
                                          name: 'password',
                                          label: 'Enter The Password',
                                          // leadingIcon: Iconsax.lock_1,
                                          inputType:
                                              TextInputType.visiblePassword,
                                          leadingIconColor:
                                              AppColors.greenYellow,
                                          enableFocusBorder: false,
                                          validator:
                                              FormBuilderValidators.compose([
                                            FormBuilderValidators.required(),
                                          ]),
                                        ),
                                      ),
                                      SizedBox(
                                        height: constraints.maxHeight * 0.07,
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Hero(
                                          tag:"button",
                                          child: PrimaryButton(
                                            label: "Login",
                                            isLoading:state is LoginLoadingState,
                                            foregroundColor: AppColors.white,
                                            backgroundColor: AppColors.blue,
                                            onPressed: (){
                                              var formData =getFormData();
                                            print(formData);
                                            cubit.loginUser(
                                                formData?["username"]?? "", formData?["password"] ??"");
                                            },
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        height: constraints.maxHeight * .047,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          SizedBox(
                                            height: constraints.maxHeight * .1,
                                            width: constraints.maxWidth * 0.45,
                                            child: FittedBox(
                                              child: Text(
                                                "Already have an account ? ",
                                                style: AppTextStyles.titleText2,
                                              ),
                                            ),
                                          ),
                                          InkWell(
                                            onTap: () {
                                              navigateTo(
                                                  context, BlocProvider.value(
                                                  value: cubit,
                                                  child: SignUp()));
                                            },
                                            child: SizedBox(
                                              height:
                                                  constraints.maxHeight * .11,
                                              width:
                                                  constraints.maxWidth * 0.27,
                                              child: FittedBox(
                                                child: Text(
                                                  "Registration",
                                                  style:
                                                      AppTextStyles.titleText,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ]);
                                  },
                                )),
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
