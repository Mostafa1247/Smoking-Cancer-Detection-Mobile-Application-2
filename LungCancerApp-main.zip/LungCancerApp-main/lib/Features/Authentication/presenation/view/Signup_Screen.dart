import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:lung_cancer/Core/Utils/App%20Textstyle.dart';
import 'package:lung_cancer/Core/Utils/Assets%20Manager.dart';
import 'package:lung_cancer/Core/Utils/Core%20Components.dart';
import 'package:lung_cancer/Core/Utils/Shared%20Methods.dart';
import 'package:lung_cancer/Features/Medical_Examination/presentation/view/medical_examination_view.dart';

import '../../../../Core/UI/primary_button.dart';
import '../../../../Core/Utils/App Colors.dart';
import '../../../../Core/Utils/top_snackbars.dart';
import '../manger/Login_Bloc.dart';
import '../manger/Login_States.dart';

class SignUp extends StatelessWidget {
  const SignUp({super.key});
  @override
  Widget build(BuildContext context) {
    AppBar appBar = AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      leading: Container(),
    );
    final mediaQueryHeight = MediaQuery.of(context).size.height;
    final mediaQueryWidth = MediaQuery.of(context).size.width;
    final mediaQueryTop = MediaQuery.of(context).padding.top;
    final mediaQuery =
        (mediaQueryHeight - appBar.preferredSize.height - mediaQueryTop);
    return BlocProvider(
      create: (context){
        return LoginCubit();
      },
      child: BlocConsumer<LoginCubit, LoginStates>(
        listener: (BuildContext context, state) {
          if (state is CreateUserSuccessState) {
            TopSnackbars().success(
                context: context,
                message: "Sign up successful! Welcome to our community!");
            Navigator.pop(context);

          }
          if(state is CreateUserErrorState){
            TopSnackbars().error(
                context: context,
                message: state.error.toString());
          }
          if(state is RegistrationErrorState){
            TopSnackbars().error(
                context: context,
                message: state.error.toString());
          }
        },
        builder: (BuildContext context, state) {
          var cubit = LoginCubit.get(context);

          return Scaffold(
            appBar: appBar,
            body: SingleChildScrollView(
              child: FormBuilder(
                key: cubit.formKey2,
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Column(
                    children: [
                      Hero(
                        tag: "sign",
                        child: SizedBox(
                          height: mediaQuery * 0.324,
                          child: Image.asset(
                            AssetsManager.onBoarding1,
                            fit: BoxFit.fill,
                          ),
                        ),
                      ),
                      const SizedBox(height: 5),
                      Row(
                        children: [
                          const SizedBox(
                            width: 5,
                          ),
                          Hero(
                            tag: "login",
                            child: Text(
                              "Sign Up ",
                              style: AppTextStyles.titleText,
                            ),
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 25,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Column(children: [
                          TextFieldTemplate(
                            name: 'FulName',
                            label: 'Enter The Full Name',
                            leadingIcon: Icons.supervised_user_circle_outlined,
                            boolleadingIcon: true,
                            leadingIconColor: AppColors.greenYellow,
                            enableFocusBorder: false,
                            titel: "Full Name",
                            validator: FormBuilderValidators.compose([
                              FormBuilderValidators.required(),
                            ]),
                          ),
                          const SizedBox(height: 15),
                          TextFieldTemplate(
                            name: 'username',
                            label: 'Enter The Email',
                            leadingIcon: Icons.mail_outline,
                            boolleadingIcon: true,
                            leadingIconColor: AppColors.greenYellow,
                            enableFocusBorder: false,
                            titel: "Email",
                            validator: FormBuilderValidators.compose([
                              FormBuilderValidators.required(),
                            ]),
                          ),
                          const SizedBox(height: 15),
                          TextFieldTemplate(
                            titel: "Password",
                            name: 'password',
                            label: 'Enter The Password',
                            // leadingIcon: Iconsax.lock_1,
                            inputType: TextInputType.visiblePassword,
                            leadingIconColor: AppColors.greenYellow,
                            enableFocusBorder: false,
                            validator: FormBuilderValidators.compose([
                              FormBuilderValidators.required(),
                            ]),
                          ),
                          const SizedBox(
                            height: 40,
                          ),
                          Hero(
                            tag: "button",
                            child: PrimaryButton(
                              label: "Sign in",
                              isLoading: state is RegistrationLoadingState,
                              foregroundColor: AppColors.white,
                              backgroundColor: AppColors.blue,
                              onPressed: () {
                                final formData = cubit.getFormData2();
                                cubit.registrationUser(
                                    email: formData?["username"],
                                    name: formData?["username"],
                                    password: formData?["password"]);
                              },
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                        ]),
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
