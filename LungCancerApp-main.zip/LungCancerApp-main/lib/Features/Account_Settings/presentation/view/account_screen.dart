
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iconsax/iconsax.dart';
import 'package:lung_cancer/Core/Utils/Assets%20Manager.dart';
import 'package:lung_cancer/Core/Utils/Core%20Components.dart';
import 'package:lung_cancer/Core/Utils/message_widget.dart';
import 'package:lung_cancer/Features/Account_Settings/presentation/manger/Account_Bloc.dart';
import 'package:lung_cancer/Features/Account_Settings/presentation/manger/Account_States.dart';
import '../../../../Core/Utils/App Colors.dart';
import '../../../../Core/Utils/App Textstyle.dart';
import '../widgets/forward_button.dart';
import '../widgets/setting_item.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  bool isDarkMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:  Text('Settings' , style: AppTextStyles.titleText.copyWith(
            fontSize: 22,
            color: AppColors.black
        ),),
        centerTitle: true,
      ),
      body: BlocProvider(
        create: (context){
          return AccountCubit()..getUserProfile();
        },
        child: BlocConsumer<AccountCubit,AccountStates>(
          listener: (context, state){},
          builder: (context, state) {
            var cubit = AccountCubit.get(context);
            return SingleChildScrollView(
              child: state is GetAccountLoadingState ? const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Center(
                    child: LoadingWidget(
                      color: AppColors.blue,
            ),
                  ),
                ],
              ): state is GetAccountErrorState ?  Padding(
              padding: const EdgeInsets.all(15.0),
              child: Center(
                child: MessageWidget(
                  message: state.error.toString(),
                ),
              ),
            ):Padding(
                padding: const EdgeInsets.all(25),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                     Text(
                      "Account" , style: AppTextStyles.titleText.copyWith(
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                        color: AppColors.black
                    )
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: Row(
                        children: [
                          Image.asset(AssetsManager.heart, width: 70, height: 70),
                          const SizedBox(width: 20),
                           Expanded(
                             flex: 5,
                             child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                 cubit.socialUserModel!.name.toString(),
                                    style: AppTextStyles.titleText.copyWith(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w500,
                                        color: AppColors.black,
                                      overflow: TextOverflow.ellipsis
                                    )
                                ),
                                const SizedBox(height: 10),
                                 Text(
                                     cubit.socialUserModel!.email.toString(),
                                 style: AppTextStyles.subTitle.copyWith(
                                   fontSize: 14
                                 )
                                )
                              ],
                          ),
                           ),
                          const Spacer(),
                          ForwardButton(
                            onTap: () {
                            },
                          )
                        ],
                      ),
                    ),
                    const SizedBox(height: 40),
                     Text(
                      "Settings", style: AppTextStyles.titleText.copyWith(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: AppColors.black
                    )),
                    const SizedBox(height: 20),
                    SettingItem(
                      title: "Language",
                      icon: Iconsax.language_circle,
                      bgColor: Colors.orange.shade100,
                      iconColor: Colors.orange,
                      onTap: () {},
                    ),
                    const SizedBox(height: 20),
                    SettingItem(
                      title: "Notifications",
                      icon: Iconsax.notification_favorite4,
                      bgColor: Colors.blue.shade100,
                      iconColor: Colors.blue,
                      onTap: () {},
                    ),
                    const SizedBox(height: 20),
                    SettingItem(
                      title: "Help",
                      icon: Icons.help_outline,
                      bgColor: Colors.red.shade100,
                      iconColor: Colors.red,
                      onTap: () {},
                    ),
                  ],
                ),
              ),
            );
          }
        ),
      ),
    );
  }
}
