
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lung_cancer/Core/Utils/Shared_preferences.dart';
import 'package:lung_cancer/Features/Authentication/data/models/SocialUserModel.dart';
import 'Account_States.dart';

class AccountCubit extends Cubit<AccountStates> {
  AccountCubit() : super(GetAccountInitialState());

  static AccountCubit get(context) {
    return BlocProvider.of(context);
  }
  var token = CacheHelper.getData("token");
  SocialUserModel? socialUserModel ;

  void getUserProfile (){
    emit(GetAccountLoadingState());
    FirebaseFirestore.instance.collection("Users").doc(token).get().then((value) {
      socialUserModel = SocialUserModel.fromJson(value.data()!);
      print(token);
      print(socialUserModel);
      emit(GetAccountSuccessState(onError.toString()));
    }).catchError((onError){
      print(onError.toString());
      emit(GetAccountErrorState(onError.message.toString()));
    });
  }
}
