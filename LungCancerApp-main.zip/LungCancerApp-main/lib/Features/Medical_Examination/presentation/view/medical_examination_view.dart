import 'package:flutter/material.dart';
import 'package:lung_cancer/Core/Utils/App%20Textstyle.dart';
import 'package:lung_cancer/Core/Utils/Shared%20Methods.dart';
import 'package:lung_cancer/Features/Home/presentation/view/tabs_screen.dart';
import '../../../../Core/UI/primary_button.dart';
import '../../../../Core/Utils/App Colors.dart';
import '../../../Home/presentation/view/home_view.dart';

class MedicalExaminationView extends StatefulWidget {
  const MedicalExaminationView({super.key});

  @override
  State<MedicalExaminationView> createState() => _MedicalExaminationViewState();
}

class _MedicalExaminationViewState extends State<MedicalExaminationView> {
  late List<int?> selectedQuestionIndices;
  late List<int?> selectedAnswerIndices;

  @override
  void initState() {
    super.initState();
    // Initialize selectedQuestionIndices and selectedAnswerIndices with null for each question
    selectedQuestionIndices =
        List.generate(healthQuestions.length, (index) => null);
    selectedAnswerIndices =
        List.generate(healthQuestions.length, (index) => null);
  }

  List<Map<String, List<String>>> healthQuestions = [
    {
      "question1": ["Do you currently smoke tobacco products?"],
      "answers": [
        "Yes - I smoke regularly",
        "No - I don't smoke",
        "Sometimes - Occasionally smoke"
      ]
    },
    {
      "question2": [
        "Do you have yellow discoloration on your fingers due to smoking?"
      ],
      "answers": [
        "Yes - I have yellowing",
        "No - I don't have yellowing",
        "Not sure"
      ]
    },
    {
      "question3": [
        "Do you frequently experience feelings of anxiety or nervousness?"
      ],
      "answers": [
        "Yes - I often feel anxious",
        "No - I don't feel anxious",
        "Occasionally"
      ]
    },
    {
      "question4": [
        "Are you influenced by peer pressure in making health-related decisions?"
      ],
      "answers": [
        "Yes - I'm often influenced",
        "No - I'm not influenced",
        "Rarely"
      ]
    },
    {
      "question5": [
        "Have you been diagnosed with any chronic diseases, such as diabetes or hypertension?"
      ],
      "answers": [
        "Yes - I have been diagnosed",
        "No - I haven't been diagnosed",
        "Not yet"
      ]
    },
    {
      "question6": ["Do you often feel unusually tired or lacking in energy?"],
      "answers": [
        "Yes - I often feel tired",
        "No - I don't feel unusually tired",
        "Sometimes"
      ]
    },
    {
      "question7": [
        "Do you have known allergies to specific substances or foods?"
      ],
      "answers": [
        "Yes - I have allergies",
        "No - I don't have allergies",
        "I'm not sure"
      ]
    },
    {
      "question8": [
        "Do you frequently experience a high-pitched whistling sound when breathing?"
      ],
      "answers": [
        "Yes - I frequently wheeze",
        "No - I don't wheeze",
        "Occasionally"
      ]
    },
    {
      "question9": ["Do you regularly consume alcoholic beverages?"],
      "answers": ["Yes - I drink regularly", "No - I don't drink", "Socially"]
    },
    {
      "question10": [
        "Do you have a persistent cough that lasts for several weeks?"
      ],
      "answers": [
        "Yes - I have a persistent cough",
        "No - I don't have a persistent cough",
        "Occasionally"
      ]
    },
    {
      "question11": [
        "Do you often feel short of breath, especially during physical activities?"
      ],
      "answers": [
        "Yes - I often feel short of breath",
        "No - I don't feel short of breath",
        "Sometimes"
      ]
    },
    {
      "question12": [
        "Do you experience difficulty swallowing food or liquids?"
      ],
      "answers": [
        "Yes - I have difficulty swallowing",
        "No - I don't have difficulty swallowing",
        "Rarely"
      ]
    },
    {
      "question13": [
        "Do you frequently experience pain or discomfort in your chest area?"
      ],
      "answers": [
        "Yes - I frequently experience chest pain",
        "No - I don't experience chest pain",
        "Occasionally"
      ]
    }
  ];

  @override
  Widget build(BuildContext context) {
    print(selectedAnswerIndices);
    bool checkNull = !selectedAnswerIndices.contains(null);
    print(checkNull);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Medical Examination',
          style: AppTextStyles.titleText
              .copyWith(fontSize: 22, color: AppColors.black),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: healthQuestions.length,
              itemBuilder: (context, index) {
                var question = healthQuestions[index];
                var questionKey = question.keys.first;
                var answers = question['answers']!;
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    elevation: 1,
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "${index + 1}${"- ${question[questionKey]![0]}"}",
                            style: AppTextStyles.titleText.copyWith(
                              fontSize: 16,
                              color: AppColors.blue,
                            ),
                          ),
                          const SizedBox(height: 8.0),
                          Column(
                            children: answers
                                .asMap()
                                .entries
                                .map(
                                  (entry) => RadioListTile<int?>(
                                    title: Text(
                                      entry.value,
                                      style: AppTextStyles.titleText2.copyWith(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.black.withOpacity(0.8),
                                      ),
                                    ),
                                    value: entry.key,
                                    activeColor: AppColors.blue,
                                    groupValue: selectedAnswerIndices[index],
                                    onChanged: (int? value) {
                                      setState(() {
                                        selectedAnswerIndices[index] = value;
                                        selectedQuestionIndices[index] = index;
                                      });
                                    },
                                  ),
                                )
                                .toList(),
                          ),
                          const SizedBox(height: 8.0),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: PrimaryButton(
              label: 'Next -->',
              backgroundColor: checkNull  == true ? AppColors.blue :AppColors.grey ,
              foregroundColor:  checkNull  == true ? Colors.white : Colors.black,
              onPressed:  checkNull  == true ? () {
                navigateAndFinished(context, const TabsScreen());
              } : null,
            ),
          ),
          const SizedBox(height: 12.0),
        ],
      ),
    );
  }
}
