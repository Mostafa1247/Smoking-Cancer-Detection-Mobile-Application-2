
import 'package:bloc/bloc.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:lung_cancer/Features/Authentication/presenation/view/onBoarding_Screen.dart';
import 'Core/Utils/App Colors.dart';
import 'Core/Utils/App Constances.dart';
import 'Core/Utils/Shared_preferences.dart';
import 'Features/Authentication/presenation/manger/BlocObserver.dart';
import 'Features/Authentication/presenation/view/Login_Screen.dart';
import 'Features/Home/presentation/view/tabs_screen.dart';


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Bloc.observer = MyBlocObserver();
  await Firebase.initializeApp();
  await CacheHelper.init();
  dynamic isBoarding  = CacheHelper.getData("isBoarding");
  AppConstances.token = CacheHelper.getData("token");
  Widget widget;
  if (kDebugMode) {
    print(isBoarding);
    print(AppConstances.token);
  }
  if (isBoarding != null) {
    if (AppConstances.token == null) {
      widget = const LoginScreen();
    } else {
      widget = const TabsScreen();
    }
  } else {
    widget = const OnBoardingScreen();
  }
  runApp(MyApp(widget: widget,));
}

class MyApp extends StatelessWidget {
  final Widget widget;
  const MyApp({super.key, required this.widget});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: AppColors.white,
        platform: TargetPlatform.iOS,
        primaryColor: AppColors.primarySwatch,
        canvasColor: Colors.transparent,
        iconTheme: const IconThemeData(color: AppColors.primaryColor, size: 25),
        primarySwatch: Colors.orange,
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.white,
          toolbarHeight: 50,
          elevation: 0,
          surfaceTintColor: AppColors.white,
          centerTitle: true,
        ),
      ),
      home: widget
    );
  }
}
