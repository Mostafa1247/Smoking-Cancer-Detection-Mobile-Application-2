abstract class AppConstances {
  static bool? isOnBoarding;
  static String locale = 'en';
  static String? token ;
  static const key = "JjwhRNk6vkyzfOpAGaAW1A==";
}