abstract class AppString {
  static const String appName = 'Food Truck';

}