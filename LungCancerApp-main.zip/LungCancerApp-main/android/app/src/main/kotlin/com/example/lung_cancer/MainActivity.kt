package com.example.lung_cancer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
